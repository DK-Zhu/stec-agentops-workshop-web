# @aip/agent-sdk

TypeScript SDK for AIP Agent Framework — Anthropic 风格的资源嵌套 API。

## 安装

```bash
npm install @aip/agent-sdk
# 或
pnpm add https://docs.example.com/sdk/aip-agent-sdk-js-1.0.0.tgz
```

## 快速开始

```typescript
import { AgentOpsClient } from "@aip/agent-sdk";

// 创建客户端（apiKey 为接入身份，自动带 Authorization 头）
const client = new AgentOpsClient({
  baseURL: "https://your-aip-host/api/v1",
  apiKey: "aip_sk_xxx",
});

// 创建 Agent
const agent = await client.agents.create({
  name: "政策查询助手",
  model: "deepseek-v4",
  systemPrompt: "你是企业政策查询助手，请根据用户的问题查询相关政策信息并总结要点。",
  tools: ["web_search"],
  skills: ["pdf_skill"],
  mcpServers: [],
});

// 创建 Session（第二参数 endUserId 为终端用户标识，建会话必填）
const session = await client.sessions.create({
  agentId: agent.agentId,
  title: "第一次接入测试",
}, "user_demo");

// 流式发送消息（每次调用显式传 endUserId）
const stream = client.messages.stream(session.sessionId, "查询年假政策", "user_demo");

for await (const event of stream) {
  switch (event.type) {
    case "part.delta":
      process.stdout.write(event.delta);
      break;
    case "tool_call.start":
      console.log(`\n[调用工具: ${event.toolName}]`);
      break;
    case "error":
      console.error(`错误: ${event.message}`);
      break;
  }
}
```

## API 参考

### Client

```typescript
const client = new AgentOpsClient({
  baseURL: string,  // API 基础 URL
  apiKey: string,   // API Key（接入身份，自动带 Authorization: Bearer 头）
});
```

### Agents

```typescript
// 创建 Agent
const agent = await client.agents.create({
  name: string,           // 名称（组织内唯一）
  model: string,          // 默认模型
  systemPrompt: string,   // 系统提示词
  tools?: string[],       // 内置工具列表
  skills?: string[],      // 内置 skill 列表
  mcpServers?: McpServerCreateParams[],  // MCP 服务器
});

// 获取 Agent
const agent = await client.agents.retrieve(agentId);

// 列出所有 Agent
const agents = await client.agents.list();

// 更新 Agent
const updated = await client.agents.update(agentId, { name: "新名称" });

// 删除 Agent
await client.agents.delete(agentId);
```

### Sessions

```typescript
// 创建 Session（endUserId 为终端用户标识，建会话必填）
const session = await client.sessions.create({
  agentId: string,
  title?: string,
  runtimeContext?: Record<string, unknown>,
}, endUserId);

// 获取 Session
const session = await client.sessions.retrieve(sessionId, endUserId);

// 列出 Agent 下的 Sessions
const sessions = await client.sessions.list(agentId, endUserId);

// 归档 Session
await client.sessions.archive(sessionId, endUserId);

// 删除已归档的 Session
await client.sessions.delete(sessionId, endUserId);

// 中止执行
const result = await client.sessions.abort(sessionId, endUserId);
```

### Messages

```typescript
// 流式发送消息（endUserId 为终端用户标识，每次调用显式传）
const stream = client.messages.stream(sessionId, "你好", endUserId, {
  model: "deepseek-v4",  // 可选：运行时覆盖模型
});

for await (const event of stream) {
  // 处理事件
}

// 发送消息并等待完整响应
const { content, events } = await client.messages.create(sessionId, {
  content: "你好",
}, endUserId);
```

### Models

```typescript
// 列出可用模型
const models = await client.models.list();
```

## 流式事件类型

| 事件类型 | 说明 | 字段 |
|---------|------|------|
| `session.status` | 会话状态变更 | `status: "running" \| "idle"` |
| `part.new` | 内容部分开始 | `partId`, `partType: "text" \| "tool_use"` |
| `part.delta` | 文本增量 | `partId`, `delta: string` |
| `part.close` | 内容部分结束 | `partId` |
| `tool_call.start` | 工具调用开始 | `toolCallId`, `toolName`, `input` |
| `tool_call.result` | 工具调用结果 | `toolCallId`, `toolName`, `output`, `isError` |
| `error` | 错误 | `code`, `message` |

## 错误处理

```typescript
import { ApiError } from "@aip/agent-sdk";

try {
  await client.agents.retrieve("non-existent");
} catch (error) {
  if (error instanceof ApiError) {
    console.log(error.status);   // 404
    console.log(error.code);     // "agent_not_found"
    console.log(error.message);  // "Agent not found"
  }
}
```

## 类型定义

SDK 导出所有相关类型：

```typescript
import type {
  Agent,
  Session,
  Model,
  MessageStreamEvent,
  // ...
} from "@aip/agent-sdk";
```

## License

MIT
